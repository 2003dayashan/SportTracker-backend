package com.example.SportsTracker.core.model;

import lombok.Data;

@Data
public class UpdateProfileRequest {
    private String username;
    private String email;
}